#!/bin/bash

STACKNAME="sa-assignment"

aws cloudformation delete-stack --stack-name=$STACKNAME